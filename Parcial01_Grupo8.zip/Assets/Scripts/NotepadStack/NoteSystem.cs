using TMPro;
using UnityEngine;
using System.Collections.Generic;

public class NoteSystem : MonoBehaviour
{
    public TMP_Text noteText;
    public TMP_Text writeText;

    private Stack<string> lines = new Stack<string>();
    private string currentLine = "";
    private bool isWriting = false;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Y))
        {
            isWriting = !isWriting;

            if (!isWriting)
            {
                writeText.text = "";
            }
        }
        else if (isWriting)
        {
            HandleTextInput();
        }
    }

    private void HandleTextInput()
    {
        foreach (char c in Input.inputString)
        {
            if (c == '\r')
            {
                if (!string.IsNullOrEmpty(currentLine))
                {
                    lines.Push(currentLine);
                    noteText.text += currentLine + "\n";
                    currentLine = "";
                }
            }
            else if (c == '\b')
            {
                if (currentLine.Length > 0)
                {
                    currentLine = currentLine.Remove(currentLine.Length - 1);
                }
            }
            else
            {
                currentLine += c;
            }

            UpdateDisplayedText();
        }
    }

    private void UpdateDisplayedText()
    {
        writeText.text = currentLine;
    }
}

