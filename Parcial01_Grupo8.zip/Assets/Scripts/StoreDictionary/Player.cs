using UnityEngine;
using UnityEngine.EventSystems;

public class Player : MonoBehaviour
{
    public Store store;

    private Item selectedItem;

    private void Start()
    {
        store.ShowItems();
    }

    public void SelectItem(Item item)
    {
        selectedItem = item;
    }

    public void OnBuyButtonClicked()
    {
        if (selectedItem != null)
        {
            store.BuyItem(selectedItem);
        }
    }

    public void OnSellButtonClicked()
    {
        if (selectedItem != null)
        {
            store.SellItem(selectedItem);
        }
    }
    public void OnSwordButtonClicked()
    {
        SelectItem(store.items[0]);
    }

    public void OnLifePotionButtonClicked()
    {
        SelectItem(store.items[1]);
    }

    public void OnShieldButtonClicked()
    {
        SelectItem(store.items[2]);
    }
}