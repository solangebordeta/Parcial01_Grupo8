using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Store : MonoBehaviour
{
    public List<Item> items;
    public List<Item> purchasedItems;
    public float playerMoney = 100f;

    public TextMeshProUGUI moneyText;
    public TextMeshProUGUI swordText;
    public TextMeshProUGUI lifePotionText;
    public TextMeshProUGUI shieldText;

    private void Start()
    {
        items = new List<Item>
        {
            new Item { itemName = "Sword", price = 50, description = "A sharp sword." },
            new Item { itemName = "Life Potion", price = 10, description = "Restores 20 life points." },
            new Item { itemName = "Shield", price = 30, description = "A strong shield." }
        };

        items.Sort((x, y) => x.price.CompareTo(y.price));
        purchasedItems = new List<Item>();
        UpdateUI();
    }

    public void BuyItem(Item item)
    {
        if (playerMoney >= item.price)
        {
            playerMoney -= item.price;
            purchasedItems.Add(item);
            Debug.Log($"You bought: {item.itemName} for {item.price}. Money left: {playerMoney}");
            UpdateUI();
        }
        else
        {
            Debug.Log("You do not have enough money to buy this item.");
        }
    }

    public void SellItem(Item item)
    {
        Debug.Log($"Purchased Items Count: {purchasedItems.Count}");

        foreach (var purchased in purchasedItems)
        {
            Debug.Log($"Purchased Item: {purchased.itemName}");
        }

        var foundItem = purchasedItems.Find(i => i.itemName == item.itemName);

        if (foundItem != null)
        {
            playerMoney += foundItem.price;
            purchasedItems.Remove(foundItem);
            Debug.Log($"You sold: {foundItem.itemName} for {foundItem.price}. Total money: {playerMoney}");
            UpdateUI();
        }
        else
        {
            Debug.Log("You cannot sell an item you haven't purchased.");
        }
    }

    public void ShowItems()
    {
        UpdateUI();
    }

    private void UpdateUI()
    {
        moneyText.text = $"Money: {playerMoney}";

        //if (items.Count > 0)
        //{
        //    swordText.text = $"Sword: {items[0].itemName}, Price: {items[0].price}";
        //}
        //if (items.Count > 1)
        //{
        //    lifePotionText.text = $"Life Potion: {items[1].itemName}, Price: {items[1].price}";
        //}
        //if (items.Count > 2)
        //{
        //    shieldText.text = $"Shield: {items[2].itemName}, Price: {items[2].price}";
        //}

        Debug.Log($"Purchased Items Count: {purchasedItems.Count}");
    }
}