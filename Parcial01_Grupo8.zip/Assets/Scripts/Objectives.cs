using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Objectives : MonoBehaviour
{
    public TextMeshProUGUI missionText;
    public Button completeMissionButton;
    private Queue<string> missionQueue;

    private void Start()
    {
        missionQueue = new Queue<string>();

        missionQueue.Enqueue("Collect 10 limes");
        missionQueue.Enqueue("Find the castle");
        missionQueue.Enqueue("Befriend the gremlins");

        DisplayNextMission();

        completeMissionButton.onClick.AddListener(CompleteMission);
    }

    private void DisplayNextMission()
    {
        if (missionQueue.Count > 0)
        {
            missionText.text = missionQueue.Peek();
        }
        else
        {
            missionText.text = "Game completed!";
        }
    }
    
    public void CompleteMission()
    {
        if (missionQueue.Count > 0)
        {
            missionQueue.Dequeue();
            DisplayNextMission();
        }
    }
 }
